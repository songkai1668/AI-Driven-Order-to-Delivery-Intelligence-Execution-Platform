# Hikari Phase 1 — An AI-Driven Solution Design
### From "document scraper + dashboard" to a self-assembling Shipment Digital Thread

*A solution concept for Bosch Connected Industry (BCI) — Hitachi DSS perspective. Scope deliberately excludes security, schedule, commercial and non-functional requirements; this is a pure capability/value design.*

---

## 0. The reframe (read this first)

BCI's RFQ describes three in-scope layers — **Data Collection**, **RPA / Application**, **Data Visualization** — and most bidders will build exactly that: an OCR pipeline that dumps fields into tables, a few Power BI tiles, and two RPA bots. That is technically compliant and commercially worthless as a differentiator, because it leaves the customer's actual pain untouched.

The actual pain is visible in the process diagram on page 3. A single customer order travels through **eight handoffs across at least six parties** — JOEM customer, RBJP planner, overseas plant, three forwarders, customs brokers, truck companies, and the warehouse — **none of whom share a system**. The only "integration" between them is **email with PDF/Excel attachments**. The planner is the human integration bus: they read every mail, mentally stitch which invoice goes with which waybill goes with which GR, and manually keep SAP in sync. That is the bottleneck, the error source, and the reason customer escalations happen.

So the design thesis is:

> **The product is not a dashboard. The product is a single, living, automatically-assembled "Digital Thread" for every shipment — and a planner copilot that acts on it.** Dashboards, alerts, and RPA all fall out of that object as natural consequences, not as separate modules.

Everything below builds toward that one object.

---

## 1. What is really going on (problem deconstruction)

Mapping BCI's eight events to what each document actually carries reveals the structure of the problem:

| # | Event (party) | Document | Key identifiers it carries |
|---|---|---|---|
| 1 | Customer order via portal (non-EDI) | Portal scrape / email | Customer PO, Part No (PN), Version, Qty, RDD |
| 2 | Planner places order in SAP | SAP order | SAP order no, references Customer PO, Material no |
| 3 | Plant sends invoice | PDF invoice | Invoice no, SAP order ref, Material, Qty, Value |
| 4 | Forwarder pre-alert / delay | PDF waybill + Cargonavi | AWB / B/L no, Container, ETD/ETA, Vessel/Flight |
| 5 | Customs broker import declaration | PDF declaration | Declaration no, references AWB/BL, HS codes |
| 6 | Truck company "combination mail" | Email/PDF | Delivery note, warehouse ref |
| 7 | Warehouse sends GR | PDF GR doc | GR no, SAP delivery, Qty received |
| 8 | Truck delivers to customer | Delivery note | Customer ref, delivery confirmation |

Two things jump out:

**(a) The hard problem is not extraction — it is entity resolution.** Each document arrives **at a different time, from a different party, in a different format, referencing the shipment by a different key.** The invoice knows the SAP order; the waybill knows the B/L; the customs declaration knows the B/L but not the SAP order; the GR knows the delivery. No single document contains the full chain. Stitching these into one canonical shipment is the work the planner does in their head today — and it is exactly what a generic OCR-to-table pipeline *fails* to do, because it lands each document type in its own silo.

**(b) Non-EDI is the crux, not an edge case.** If these partners had EDI, BCI wouldn't need this project. The entire value is in turning an *un-integrated, document-based, human-mediated* process into a *machine-readable digital thread* — without forcing any partner to change how they work.

This is why "another dashboard" misses the point. A dashboard over un-stitched data just visualizes the chaos faster.

---

## 2. The core idea: the Shipment Digital Thread

Define one first-class object — call it the **Shipment Digital Thread (SDT)** — that represents the full lifecycle of one customer order from portal to doorstep. It is *not* a row in a table; it is an **event-sourced state machine** that accretes evidence as documents arrive.

```
ORDER_RECEIVED → ORDER_PLACED → INVOICED → PRE_ALERT(ETD/ETA) →
DEPARTED → ARRIVED_PORT → CUSTOMS_CLEARED → AT_WAREHOUSE →
GOODS_RECEIVED → SHIPPED_TO_CUSTOMER → DELIVERED
```

Each state transition is *triggered by a document* (or a Cargonavi scrape, or an SAP sync). Each transition has an **expected timestamp** learned from historical lane performance. The SDT therefore knows, at any moment:

- where the shipment physically is,
- which documents have / haven't arrived,
- whether each milestone is early, on-time, or late versus the learned baseline,
- and what the predicted downstream dates are.

**This single object is the source of almost every requirement BCI listed**, which I'll show in §4. It is also the asset that makes Phase 2/3 agentic use cases possible — you cannot build "inventory forecast agent" or "disruption alert agent" on top of disconnected document tables, but you *can* build them trivially on top of a clean, stitched, milestone-tracked thread.

---

## 3. Architecture — the three in-scope layers, reimagined

### 3.1 Ingestion — Agentic IDP, not template OCR

BCI's table lists "OCR" against most document types. Template-based OCR is the wrong tool here: you have ~10 forwarders, multiple plants, multiple truck companies, each with their own evolving layouts. Template OCR breaks the day a forwarder moves a field, and breakage is silent.

Propose **schema-guided Intelligent Document Processing (IDP)** instead:

- Define a **target schema per document class** (invoice, waybill, declaration, GR…) — the *fields you want*, not the layout you expect.
- Use a **vision-language model (VLM)** to extract directly to that schema from the PDF image, so layout drift doesn't matter. The model reads the document the way a human does.
- Every extracted field carries a **confidence score** and a **source bounding box** (provenance), so nothing is a black box.
- Low-confidence or business-rule-failing extractions route to a lightweight **human validation queue** (an Angular review screen) — the human corrects, and that correction becomes a few-shot example that improves the next extraction. The system *self-heals and learns* rather than silently degrading.

This is the difference between "an OCR script someone has to babysit" and "an extraction service that gets more accurate over time and tells you when it's unsure." It directly satisfies the "基于模板或 AI 辅助" intent in their spec — just executed at state-of-the-art.

n8n remains the orchestration spine (email monitoring → dispatch to IDP service → archive raw to SharePoint → write structured to Doris), exactly as BCI envisages. The intelligence lives in a Python IDP microservice that n8n calls.

### 3.2 The Stitching Engine — the differentiator

This is the part no commodity bidder will build, and it is where the money is.

When a document is extracted, it doesn't just get inserted — it gets **resolved against existing threads**. The engine maintains a key-graph: `Customer PO ↔ SAP Order ↔ Invoice No ↔ AWB/BL ↔ Container ↔ Customs Decl ↔ Delivery ↔ GR`. A new document carries one or two of these keys; the engine joins it transitively to the correct SDT.

Three techniques make this robust:

1. **Deterministic matching** on clean keys (exact SAP order / invoice / B/L numbers).
2. **Fuzzy matching** for OCR noise and format variants (e.g. `BL-2026-0042` vs `BL 2026 42`), with normalization rules per key type.
3. **AI-assisted disambiguation** when keys are missing or ambiguous — the LLM reasons over partial evidence ("this declaration's container matches two open shipments, but only one has a matching plant origin and ETA window") and proposes a link *with a confidence score*. Ambiguous links above a threshold auto-bind; below it, they go to the same human queue.

The output is a continuously maintained set of complete, traceable shipment threads. **This is the single source of truth the planner has never had.**

### 3.3 Lifecycle & exception engine

With the SDT as a state machine, "early warning" stops being a bespoke feature and becomes a **byproduct**:

- Each expected transition carries an **SLA timer** seeded from historical lane/forwarder performance.
- A timer breach, a "delay notification" in a forwarder pre-alert, or a missing document = an **exception event** on the thread.
- Exceptions are typed (transit delay, customs hold, GR mismatch, quantity discrepancy) and ranked by **customer impact** (does this threaten the customer's required delivery date?).

That single mechanism produces BCI's "运输提前预警" (shipment early warning) directly — and produces it *predictively and prioritized*, not as a flat table of late items.

### 3.4 Predictive layer

Two models, both cheap to build once the SDT exists because the thread *is* the labeled training data:

- **ETA / completion prediction** — gradient-boosted model over `lane × mode (air/sea) × forwarder × current-milestone` predicting arrival, customs-clear, GR and final-delivery dates. Compare predicted final delivery to the customer's required date → a **risk score per shipment** that drives the warning page. This is what turns "it's already late" (reactive) into "it *will* be late, act now" (the actual value).
- **Demand-pattern detection** — time-series anomaly detection on SAP order quantity by `Customer × PN × Version` over the rolling 12 months. This is BCI's "客户订单量波动预警" — but instead of a static chart, it surfaces *a narrated alert to the planner*: "Customer A's volume on PN-X is up 38% vs trailing quarter; current lane capacity assumes the old run-rate."

### 3.5 The Planner Copilot — the "not just a dashboard" layer

This is the experience layer that makes the whole thing feel like a product rather than a report. On top of the SDT and the models, build a **conversational + agentic copilot** (Angular front end; agent runtime calling tools over your data and SAP). It does three things a dashboard cannot:

1. **Answers natural-language questions** grounded in the thread: *"Where is the Toyota order from last Tuesday?"*, *"Which shipments are at risk of missing RDD this week and why?"*, *"Show me every order touching Forwarder 2 that's stuck in customs."* Answers are grounded in stitched data with document provenance — click a claim, see the source PDF region. This is what keeps it trustworthy and not a hallucination machine.
2. **Proactively nudges** — instead of waiting to be opened, it pushes the prioritized exception list and drafts the response (see below).
3. **Drafts and takes actions** — the bridge to the RPA layer.

The dashboard still exists (Power BI / Angular) for the lane map and KPI overview that BCI asked for — but it is the *passive* surface. The copilot is the *active* one, and it's the reason a planner opens the tool every morning.

### 3.6 Confidence-gated action layer (the RPA, done responsibly)

BCI wants three automations: **SAP GR**, **SAP ASN update**, **non-EDI order capture**. The naïve approach fires RPA blindly off a trigger. The state-of-the-art approach — and one that maps directly to a hallucination-tolerance / graduated-autonomy framework — gates every action by **reversibility × confidence**:

| Action | Blast radius | Default autonomy |
|---|---|---|
| Answer a query / show status | None (read-only) | Fully autonomous |
| Draft the truck "combination mail" / customer reply | Low (human sends) | Auto-draft, human sends |
| **SAP ASN update** | Medium | Auto if extraction confidence high *and* thread validated; else queue |
| **SAP GR posting** | High (inventory/financial) | Human-confirm by default; graduates to auto per document-type as measured accuracy proves out |
| Non-EDI order capture | Medium | Auto-capture + structured proposal; planner confirms order placement |

The trigger for each action is **a state transition on the SDT**, not a standalone bot. ASN update fires when the pre-alert sets ETD/ETA; GR proposal fires when the warehouse GR document lands and reconciles against the open SAP delivery. Because the thread already reconciled quantities and references, the RPA has *verified inputs* — which is precisely why these automations are safe enough to trust.

This is the part worth emphasizing to BCI given Bosch's quality culture: **you are not selling reckless automation, you are selling automation with a confidence model, provenance, and a human-in-the-loop fallback** — autonomy that earns trust before it takes it.

---

## 4. Coverage proof — every BCI requirement falls out of the design

To show this is workable and fully compliant, not vapor:

**Data Collection table (items 1–29)** → the Agentic IDP service + n8n orchestration handle every document class (SAP invoice, air/sea waybill, tracking list, import declaration, truck docs, warehouse GR/shipment docs), plus the Cargonavi scrape (item 9). Email monitoring, SharePoint archival, OCR/Excel processing, and Doris upload are all covered — the only change is *OCR → schema-guided IDP* and *insert → stitch-then-insert*.

**RPA table (items 1–9)** → §3.6. GR, ASN, and non-EDI order capture, each triggered by SDT state transitions, each confidence-gated.

**Visualization table (items 1–10)** →
- Shipment early warning (1–3): from the lifecycle/SLA engine + risk score, surfaced via copilot and warning page.
- Customer order-volume warning (4–6): from the demand-pattern model on SAP order qty.
- Transport-flow map (7): the SDT carries geolocated milestones (origin port → Japan port → warehouse → customer), so the map renders the *actual stitched flow*, not a static diagram.
- Data integration, filters, SSO (8–10): standard, satisfied by the Doris-backed Angular app.

Nothing in BCI's scope is dropped. The architecture is a **superset** — it does everything they asked, organized around an object that makes it worth more.

---

## 5. Why this is money-for-value

The value is not "we collected your PDFs." It is measurable in the planner's day and the customer relationship:

- **Eliminates manual stitching** — the planner stops being the human integration bus. Hours/day of mail-reading and cross-referencing collapse to reviewing an exception queue.
- **Prevents escalations, doesn't just report them** — predictive risk scoring catches "will be late" days earlier than "is late."
- **Reduces SAP keying errors** — GR/ASN automation runs off reconciled, provenance-backed data, not re-keyed numbers.
- **Builds the asset for Phase 2/3** — and this is the strategic clincher. Every Phase 2/3 idea in BCI's own slide (truckload optimization, warehouse bundling, layout optimization, inventory-forecast / cost-optimization / supplier-risk / ETA / disruption agents) is *impossible on siloed document tables* and *straightforward on a clean Digital Thread*. By building the SDT now, Phase 1 quietly becomes the foundation that makes BCI's entire AI roadmap fundable. You're not bidding a project; you're bidding the substrate for their next two phases.

---

## 6. Build approach with BCI's stated stack (pragmatic, not exotic)

The design uses exactly the tools BCI named, so it's defensible in evaluation:

- **n8n** — orchestration spine (email triggers, dispatch, archival, Doris writes, RPA triggers). Unchanged from their intent.
- **Python** — the IDP service (VLM extraction + confidence), the stitching engine, the ETA/demand models.
- **Doris** — stores both the structured fields *and* the SDT event log (Doris handles the analytical + time-series load well). The thread is materialized as views over the event store.
- **Angular** — the validation queue, the copilot UI, the warning pages, the lane map (Bosch Webcore for UX compliance).
- **RPA / Webservice** — SAP GR/ASN as BCI specified, behind the confidence gate.
- **Agent runtime + tool-calling** (e.g. MCP-style tools over Doris/SAP) — the copilot's brain. This is where the genuinely new capability sits, and it's a thin, well-contained addition.

Pragmatic guardrails so it stays buildable in scope: start the SDT with the ~5 document classes that carry the join keys (invoice, waybill, declaration, GR, customer order); keep the ETA model simple (gradient boosting, not deep learning) until there's enough thread history; ship GR automation in "propose, human-confirms" mode first and graduate it. Nothing here requires research-grade ML — it requires *good systems design around one strong idea*.

---

## 7. What to say in one sentence to BCI

> "Most vendors will hand you a document scraper and a dashboard. We'll hand you a living digital thread for every shipment that assembles itself from the email chaos, tells your planners what's about to go wrong before it does, and acts on SAP with a confidence model you can trust — and that same thread is the foundation your Phase 2 and Phase 3 AI agents will need anyway."

That is the difference between competing on price for "another app" and being the partner who reframes the problem.

---

*Next steps if useful: (a) a one-page architecture diagram of the SDT pipeline, (b) a slimmed Phase-1 MVP scope that proves the stitching engine on two document classes, or (c) a slide version of the §0 reframe + §7 pitch for the BCI conversation.*
